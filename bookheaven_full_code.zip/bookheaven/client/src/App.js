// Main App component
import React from 'react';
function App() {
  return <div>Welcome to Book Heaven</div>;
}
export default App;